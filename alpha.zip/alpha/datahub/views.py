# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

# Create your views here.
from django.views import generic
from .models import Post
import models

class PostList(generic.ListView):
    queryset = Post.objects.filter(status=1).order_by('-created_on')
    template_name = 'post_list.html'

class PostDetail(generic.DetailView):
    model = Post
    template_name = 'post_detail.html'

# call these functions every time user requests page information

def collectpage(req):
    return render(req, 'index.html')

def endpage(req):
    
    # handle the data for database
    dbcls = models.DBcontroller()
    username = req.GET['name']
    phonenum = req.GET['phoneinputer']
    address = req.GET['homeaddrinputer']
    qq = req.GET['qqnuminputer']
    id = req.GET['idnuminputer']
    email = req.GET['emailaddrinputer']
    userinf = {'name':username, 'phone':phonenum, 'address':address, 'qq':qq, 'id':id, 'email':email}
    dbcls.setnewdata(userinf) # add new data to database
    infor = 'thanks for your cooperation'

    return render(req, 'indexb.html', context= {'enddata':infor})

def testpage(request):
    return render(request, 'test.html')
 
def testbpage(request):
    data = request.GET['fulltextarea']
    return render(request, 'testb.html', context= {'data':data})