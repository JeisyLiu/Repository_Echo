from . import views
from django.conf.urls import url

urlpatterns = [
#     # url('', views.collectpage, name='home'),
    url('indexb/', views.endpage, name= 'submit_info'),
    url('testb/', views.testbpage, name='my_function'),
    url('', views.collectpage),
     
#     # url('<slug:slug>/', views.PostDetail.as_view(), name='post_detail'),
]
