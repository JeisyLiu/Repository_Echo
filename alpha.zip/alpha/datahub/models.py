# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
from django.http import HttpResponse
import sqlite3 as sql 
import csv

# Create your models here.

STATUS = (
    (0,"Draft"),
    (1,"Publish")
)

class Post(models.Model):
    title = models.CharField(max_length=200, unique=True)
    slug = models.SlugField(max_length=200, unique=True)
    author = models.ForeignKey(User, on_delete= models.CASCADE,related_name='blog_posts')
    updated_on = models.DateTimeField(auto_now= True)
    content = models.TextField()
    created_on = models.DateTimeField(auto_now_add=True)
    status = models.IntegerField(choices=STATUS, default=0)

    class Meta:
        ordering = ['-created_on']

    def __str__(self):
        return self.title


class DBcontroller:
    def __init__(self):
        self.connector =  sql.connect('datahub/infdb')
        self.dbcursor = self.connector.cursor()

    def getalldata(self):
        self.dbcursor.execute('SELECT * FROM Datahub')
        tablerows = self.dbcursor.fetchall()
        self.connector.close()
        return tablerows
    
    def setnewdata(self, infodict):
        csvfile =  open('contactdatabase.csv', 'w')
        spamwriter = csv.writer(csvfile)

        self.dbcursor.execute('INSERT INTO Datahub VALUES("'+infodict['name']+'", "'+ infodict['phone']+'", "'+ infodict['address']+'", "'+ infodict['qq']+'", "'+ infodict['id']+'", "'+ infodict['email']+ '")')
        print ('the data has been saved to database: Datahub in infdb')
        # Show all of the data
        print ('--------------- all of the rows ----------------')
        self.dbcursor.execute('SELECT * FROM Datahub')
        for lines in self.dbcursor.fetchall():
            # Save all of the rows
            spamwriter.writerow(lines)
            print (lines)
        self.connector.commit()
        self.connector.close()


def saveToLocal(request):
    # Create the HttpResponse object with the appropriate CSV header.
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="tmp.csv"'
    writer = csv.writer(response)
    writer.writerow(['First row', 'Foo', 'Bar', 'Baz'])
    writer.writerow(['Second row', 'A', 'B', 'C', '"Testing"', "Here's a quote"])
    return response