import csv
csvfile =  open('tamago.csv', 'w')

spamwriter = csv.writer(csvfile, delimiter=' ', quotechar='|', quoting= csv.QUOTE_MINIMAL)
spamwriter.writerow(['Spam'] * 5 + ['Baked Beans'])
spamwriter.writerow(['Spam', 'Lovely Spam', 'Wonderful Spam'])