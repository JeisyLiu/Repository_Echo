import sqlite3 as sql 
import sys

connector = sql.connect('../datahub/infdb')
dbcursor = connector.cursor()

# dbcursor.execute('CREATE TABLE Datahub(name VARCHAR(10), phone VARCHAR(20), qq VARCHAR(20), address VARCHAR(20), id VARCHAR(20), email VARCHAR(20)')
# dbcursor.execute('CREATE TABLE User(login VARCHAR(8), uid INT)')
# dbcursor.execute('SELECT * FROM People')
# for rowunit in dbcursor.fetchall():
#     print (rowunit)

def printAllData():
    dbcursor.execute('SELECT * FROM Datahub')
    for rowmem in dbcursor.fetchall():
        print rowmem

def insertData(name, phone, address, qq, id, email):
    dbcursor.execute('INSERT INTO Datahub VALUES("'+name+'","'+ phone+'","'+address+'","'+qq+'","'+id+'","'+email+'")')
    print 'the data is inserted '

if sys.argv[1] == '0':
    insertData("charlie", "12121", "brookyn", "65656", "78787", "wwww")
    printAllData()

else:
    printAllData()

connector.commit()
connector.close()
